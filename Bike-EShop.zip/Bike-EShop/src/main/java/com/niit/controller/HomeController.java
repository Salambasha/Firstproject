package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	public HomeController() {

		System.out.println("Creating the Controller");
	}

	@RequestMapping("/")
	public String homepage() {
		return "home";
	}

	@RequestMapping("/register")
	public String register() {
		return "register";
	}

	@RequestMapping("/home")
	public String home() {
		return "home";
	}

	@RequestMapping("/ContactUs")
	public String contact() {
		return "ContactUs";
	}
	@RequestMapping("/AboutUs")
	public String aboutus() {
		return "AboutUs";
	}
	@RequestMapping("/LogIn")
	public String login() {
		return "LogIn";
	}
}
