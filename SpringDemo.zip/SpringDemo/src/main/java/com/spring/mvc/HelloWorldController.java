package com.spring.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	@RequestMapping("/home")
	public ModelAndView helloWorld(){
		return new ModelAndView("welcome","message","Welcome to Spring MVC Framework" );
		
	}
	

}
