package model;

public class LoginCredentials {
	private String Uname,Passwd;
	
	public boolean check()
	{
		if(Uname.equals("SALAM")&& Passwd.equals("12345"))
			return true;
		else 
			return false;
	}

	public String getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		this.Uname = uname;
	}

	public String getPasswd() {
		return Passwd;
	}

	public void setPasswd(String passwd) {
		Passwd = passwd;
	}
	
	

}
