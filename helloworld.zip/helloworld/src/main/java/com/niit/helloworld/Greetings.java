package com.niit.helloworld;

public interface Greetings {
	public String SayGreetings();
		


}
