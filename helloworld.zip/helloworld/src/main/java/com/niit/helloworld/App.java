package com.niit.helloworld;
import org.springframework.context.ApplicationContext;

import org.springframework.context.support.FileSystemXmlApplicationContext;
import com.niit.di.*;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        ApplicationContext context=new FileSystemXmlApplicationContext("beans.xml");
        Greetings greetings=(GreetingsImpl)context.getBean("greetingsObj");
        System.out.println(greetings.SayGreetings());
        
        Greetings greetingsCons=(GreetingsImpl)context.getBean("greetingsCons");
        System.out.println(greetingsCons.SayGreetings());
        
        Traveller traveller =(Traveller)context.getBean("veller");
        System.out.println(traveller.getTravelDetails());
        		
       
        
        
    }
    
    
}
