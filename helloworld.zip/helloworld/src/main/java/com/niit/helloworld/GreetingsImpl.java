package com.niit.helloworld;

public class GreetingsImpl implements Greetings {
	private String message;
	
	
	public GreetingsImpl() {
		
	}


	public GreetingsImpl(String message) {
	    
		this.message = message;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String SayGreetings() {
		// TODO Auto-generated method stub
		return this.message + "using Spring Framework";
		
		
	}

}
