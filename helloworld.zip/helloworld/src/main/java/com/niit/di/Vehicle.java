package com.niit.di;

public interface Vehicle {

	double getCostDetails();
}
