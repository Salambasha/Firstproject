package com.niit.di;

public class Traveller {

	int kmTravelled;
	Vehicle vehicle;
	public int getKmTravelled() {
		return kmTravelled;
	}
	public void setKmTravelled(int kmTravelled) {
		this.kmTravelled = kmTravelled;
	}
	public Vehicle getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public String getTravelDetails(){
		return "Total Cost" + this.kmTravelled*vehicle.getCostDetails();
		
	}
}
