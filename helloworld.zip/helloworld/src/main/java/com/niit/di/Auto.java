package com.niit.di;

public class Auto implements Vehicle {
	double priceperkm;
	

	public double getPriceperkm() {
		return priceperkm;
	}


	public void setPriceperkm(double priceperkm) {
		this.priceperkm = priceperkm;
	}


	public double getCostDetails() {
		// TODO Auto-generated method stub
		return priceperkm;
	}
	

}
