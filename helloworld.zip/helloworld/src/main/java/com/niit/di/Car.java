package com.niit.di;

public class Car implements Vehicle {
	
	double costperkm;
	

	public double getCostperkm() {
		return costperkm;
	}


	public void setCostperkm(double costperkm) {
		this.costperkm = costperkm;
	}

	public double getCostDetails() {
		// TODO Auto-generated method stub
		return this.costperkm;
	}

}
